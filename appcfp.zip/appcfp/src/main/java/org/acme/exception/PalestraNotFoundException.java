package org.acme.exception;

public class PalestraNotFoundException  extends RuntimeException{
}
